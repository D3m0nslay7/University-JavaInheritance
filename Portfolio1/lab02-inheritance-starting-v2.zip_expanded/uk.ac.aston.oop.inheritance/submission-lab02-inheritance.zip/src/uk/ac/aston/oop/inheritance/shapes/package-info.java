/**
 * Main package of the inheritance shapes i created.
 *
 * @author Umer
 * @version 1.5
 */

package uk.ac.aston.oop.inheritance.shapes;